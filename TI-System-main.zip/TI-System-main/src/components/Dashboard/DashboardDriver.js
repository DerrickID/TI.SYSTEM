// src/components/HomePage.js
import React from 'react';

const DashboardDriver = () => {
  return (
    <div>
      <h1>DashBoard Driver</h1>
      {/* Your home page content goes here */}
    </div>
  );
};

export default DashboardDriver;
